package com.zoya.ai

object Ids {
    private var n = System.currentTimeMillis()
    @Synchronized
    fun next(): Long = ++n
}

data class ChatMessage(
    val id: Long = Ids.next(),
    val role: String,          // "user" or "assistant"
    val text: String,
    val isError: Boolean = false
)

/** ok = null means "in progress". */
data class Status(val text: String, val ok: Boolean?)
