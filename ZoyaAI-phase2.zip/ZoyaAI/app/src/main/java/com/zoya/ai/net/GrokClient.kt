package com.zoya.ai.net

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/** Talks to the official xAI API (OpenAI-compatible): https://api.x.ai/v1 */
class GrokClient(private val http: OkHttpClient) {

    private val base = "https://api.x.ai/v1"

    /** Asks xAI which models this key can use, so we never guess model names. */
    suspend fun listModels(apiKey: String): Result<List<String>> = withContext(Dispatchers.IO) {
        try {
            val req = Request.Builder()
                .url("$base/models")
                .header("Authorization", "Bearer ${apiKey.trim()}")
                .get()
                .build()
            http.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw ApiErrors.http("xAI", resp.code, body)
                val arr = JSONObject(body).getJSONArray("data")
                val ids = (0 until arr.length()).map { arr.getJSONObject(it).getString("id") }
                    .filterNot { it.contains("image", true) || it.contains("imagine", true) || it.contains("video", true) }
                    .sorted()
                Result.success(ids)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /** messages = list of (role, content) where role is system / user / assistant. */
    suspend fun chat(
        apiKey: String,
        model: String,
        temperature: Float,
        messages: List<Pair<String, String>>,
        maxTokens: Int? = null
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val msgs = JSONArray()
            messages.forEach { (role, content) ->
                msgs.put(JSONObject().put("role", role).put("content", content))
            }
            val payload = JSONObject()
                .put("model", model.trim())
                .put("messages", msgs)
                .put("temperature", temperature.toDouble())
                .put("stream", false)
            if (maxTokens != null) payload.put("max_tokens", maxTokens)

            val req = Request.Builder()
                .url("$base/chat/completions")
                .header("Authorization", "Bearer ${apiKey.trim()}")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()
            http.newCall(req).execute().use { resp ->
                val body = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw ApiErrors.http("xAI", resp.code, body)
                val text = JSONObject(body)
                    .getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .optString("content")
                    .trim()
                if (text.isEmpty()) throw ApiException("Grok returned an empty reply. Try again.")
                Result.success(text)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
