package com.zoya.ai

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zoya.ai.net.ApiErrors
import com.zoya.ai.net.ElevenLabsClient
import com.zoya.ai.net.GrokClient
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    val settings = SettingsStore(app)

    private val http = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()
    private val grok = GrokClient(http)
    private val eleven = ElevenLabsClient(http)
    private val player = ZoyaPlayer()
    private val chatPrefs = app.getSharedPreferences("zoya_chat", Context.MODE_PRIVATE)

    val messages = mutableStateListOf<ChatMessage>()
    var isThinking by mutableStateOf(false); private set
    var isSpeaking by mutableStateOf(false); private set
    var banner by mutableStateOf<String?>(null); private set
    var voiceEnabled by mutableStateOf(settings.voiceEnabled); private set

    var grokStatus by mutableStateOf<Status?>(null); private set
    var elevenStatus by mutableStateOf<Status?>(null); private set
    var availableModels by mutableStateOf<List<String>>(emptyList()); private set

    private var speakJob: Job? = null
    private var speakGen = 0

    init {
        loadChat()
    }

    // ---------- Chat ----------

    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty() || isThinking) return

        banner = null
        messages.add(ChatMessage(role = "user", text = t))

        val key = settings.grokKey
        val model = settings.model
        if (key.isBlank() || model.isBlank()) {
            messages.add(
                ChatMessage(
                    role = "assistant",
                    text = "Please open Settings, add your Grok API key and choose a model first.",
                    isError = true
                )
            )
            return
        }

        stopSpeaking()
        isThinking = true
        saveChat()

        viewModelScope.launch {
            val history = ArrayList<Pair<String, String>>()
            history.add("system" to Persona.systemPrompt(settings))
            messages.filterNot { it.isError }.takeLast(20).forEach { history.add(it.role to it.text) }

            val result = grok.chat(key, model, settings.temperature, history)
            isThinking = false
            result.onSuccess { reply ->
                messages.add(ChatMessage(role = "assistant", text = reply))
                saveChat()
                if (voiceEnabled) speak(reply)
            }.onFailure { e ->
                messages.add(ChatMessage(role = "assistant", text = ApiErrors.describe(e), isError = true))
            }
        }
    }

    fun clearChat() {
        stopSpeaking()
        messages.clear()
        saveChat()
    }

    fun dismissBanner() {
        banner = null
    }

    // ---------- Voice (ElevenLabs) ----------

    fun toggleVoice() {
        voiceEnabled = !voiceEnabled
        settings.voiceEnabled = voiceEnabled
        if (!voiceEnabled) stopSpeaking()
    }

    /** Only one voice reply can play at a time: starting a new one cancels the old one. */
    fun speak(text: String) {
        val key = settings.elevenKey
        val voice = settings.voiceId
        if (key.isBlank() || voice.isBlank()) {
            banner = "Voice is off. Add your ElevenLabs API key and Voice ID in Settings."
            return
        }
        stopSpeaking()
        val gen = speakGen
        isSpeaking = true
        speakJob = viewModelScope.launch {
            val r = eleven.synthesize(key, voice, text, getApplication<Application>().cacheDir)
            if (r.isSuccess) {
                val played = player.play(r.getOrThrow())
                if (played.isFailure) banner = ApiErrors.describe(played.exceptionOrNull()!!)
            } else {
                banner = "Voice error: " + ApiErrors.describe(r.exceptionOrNull()!!)
            }
            if (gen == speakGen) isSpeaking = false
        }
    }

    fun stopSpeaking() {
        speakJob?.cancel()
        speakJob = null
        player.stop()
        speakGen++
        isSpeaking = false
    }

    // ---------- Connection tests ----------

    fun testGrok(key: String, model: String) {
        if (key.isBlank()) {
            grokStatus = Status("Enter your Grok API key first.", false)
            return
        }
        grokStatus = Status("Testing connection…", null)
        viewModelScope.launch {
            val models = grok.listModels(key)
            if (models.isFailure) {
                grokStatus = Status(ApiErrors.describe(models.exceptionOrNull()!!), false)
                return@launch
            }
            val list = models.getOrThrow()
            availableModels = list
            if (model.isBlank()) {
                grokStatus = Status(
                    "Key works ✓ ${list.size} models available. Pick one, then press Test again.",
                    true
                )
                return@launch
            }
            if (list.isNotEmpty() && model.trim() !in list) {
                grokStatus = Status(
                    "Key works, but \"${model.trim()}\" is not in your available models. Use \"Pick model\".",
                    false
                )
                return@launch
            }
            val chat = grok.chat(
                key, model, 0.2f,
                listOf("user" to "Reply with the single word: ok"),
                maxTokens = 16
            )
            grokStatus = if (chat.isSuccess) {
                Status("Connected ✓ Model \"${model.trim()}\" is working.", true)
            } else {
                Status(ApiErrors.describe(chat.exceptionOrNull()!!), false)
            }
        }
    }

    fun testEleven(key: String, voiceId: String) {
        if (key.isBlank() || voiceId.isBlank()) {
            elevenStatus = Status("Enter both your ElevenLabs API key and Voice ID first.", false)
            return
        }
        stopSpeaking()
        elevenStatus = Status("Generating a short test voice…", null)
        val gen = speakGen
        speakJob = viewModelScope.launch {
            val r = eleven.synthesize(
                key, voiceId, "Hi, I am Zoya. Can you hear me?",
                getApplication<Application>().cacheDir
            )
            if (r.isFailure) {
                elevenStatus = Status(ApiErrors.describe(r.exceptionOrNull()!!), false)
                return@launch
            }
            elevenStatus = Status("Playing Zoya's voice… 🔊", null)
            val played = player.play(r.getOrThrow())
            elevenStatus = if (played.isSuccess) {
                Status("Voice works ✓", true)
            } else {
                Status(ApiErrors.describe(played.exceptionOrNull()!!), false)
            }
            if (gen == speakGen) isSpeaking = false
        }
    }

    fun clearGrokStatus() { grokStatus = null }
    fun clearElevenStatus() { elevenStatus = null }

    // ---------- Persistence of chat history (last 60 messages) ----------

    private fun saveChat() {
        val arr = JSONArray()
        messages.filterNot { it.isError }.takeLast(60).forEach {
            arr.put(JSONObject().put("r", it.role).put("t", it.text))
        }
        chatPrefs.edit().putString("history", arr.toString()).apply()
    }

    private fun loadChat() {
        try {
            val arr = JSONArray(chatPrefs.getString("history", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                messages.add(ChatMessage(role = o.getString("r"), text = o.getString("t")))
            }
        } catch (e: Exception) {
            // ignore corrupted history
        }
    }

    override fun onCleared() {
        player.stop()
        super.onCleared()
    }
}
