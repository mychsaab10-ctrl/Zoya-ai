package com.zoya.ai

import android.media.AudioAttributes
import android.media.MediaPlayer
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume

/** Plays one audio file at a time and always cleans up (release + delete file). */
class ZoyaPlayer {

    private var mp: MediaPlayer? = null

    suspend fun play(file: File): Result<Unit> = suspendCancellableCoroutine { cont ->
        stop()
        val p = MediaPlayer()
        mp = p

        fun cleanup() {
            try { p.release() } catch (_: Exception) {}
            if (mp === p) mp = null
            file.delete()
        }

        try {
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            p.setDataSource(file.absolutePath)
            p.setOnPreparedListener { it.start() }
            p.setOnCompletionListener {
                cleanup()
                if (cont.isActive) cont.resume(Result.success(Unit))
            }
            p.setOnErrorListener { _, _, _ ->
                cleanup()
                if (cont.isActive) cont.resume(Result.failure(Exception("Audio playback failed.")))
                true
            }
            p.prepareAsync()
        } catch (e: Exception) {
            cleanup()
            if (cont.isActive) cont.resume(Result.failure(e))
        }

        cont.invokeOnCancellation { cleanup() }
    }

    fun stop() {
        val p = mp ?: return
        mp = null
        try { p.stop() } catch (_: Exception) {}
        try { p.release() } catch (_: Exception) {}
    }
}
