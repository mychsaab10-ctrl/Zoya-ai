package com.zoya.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.zoya.ai.call.CallState
import com.zoya.ai.call.CallViewModel

@Composable
fun CallScreen(vm: CallViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    val view = LocalView.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var permissionDenied by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionDenied = !granted
        if (granted) vm.startCall()
    }

    fun begin() {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) {
            permissionDenied = false
            vm.startCall()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    // Keep the screen on during a call.
    DisposableEffect(vm.active) {
        view.keepScreenOn = vm.active
        onDispose { view.keepScreenOn = false }
    }

    // Microphone can't be used in the background: end the call if the app is hidden.
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                vm.endCall("Call ended because the app went to the background.")
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val listState = rememberLazyListState()
    LaunchedEffect(vm.lines.size) {
        if (vm.lines.isNotEmpty()) listState.animateScrollToItem(vm.lines.size - 1)
    }

    val statusLabel = when {
        !vm.active -> "Not in a call"
        vm.muted -> "Muted 🔇"
        else -> when (vm.state) {
            CallState.LISTENING -> "Listening…"
            CallState.THINKING -> "Thinking…"
            CallState.SPEAKING -> "Speaking…"
            CallState.IDLE -> "Connecting…"
        }
    }

    val target = when {
        !vm.active -> 0.45f
        vm.muted -> 0.4f
        vm.state == CallState.LISTENING -> 0.5f + vm.level * 0.5f
        vm.state == CallState.SPEAKING -> 0.9f
        vm.state == CallState.THINKING -> 0.65f
        else -> 0.5f
    }
    val circle by animateFloatAsState(target, label = "circle")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .padding(horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = {
                vm.endCall(null)
                onBack()
            }) { Text("← Back") }
            Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Call with Zoya", style = MaterialTheme.typography.titleMedium)
                Text(
                    vm.connectionLabel + if (vm.active) "  •  " + "%02d:%02d".format(vm.seconds / 60, vm.seconds % 60) else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (vm.active && (!vm.online || vm.apiProblem)) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Spacer(Modifier.size(64.dp))
        }

        Spacer(Modifier.height(8.dp))
        Box(modifier = Modifier.size(150.dp), contentAlignment = Alignment.Center) {
            Box(
                modifier = Modifier
                    .size((150f * circle).dp)
                    .alpha(if (vm.active) 1f else 0.5f)
                    .background(MaterialTheme.colorScheme.primary, CircleShape)
            )
        }
        Text(statusLabel, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(8.dp))

        vm.notice?.let { msg ->
            Text(
                msg + "  (tap to dismiss)",
                color = MaterialTheme.colorScheme.onErrorContainer,
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.errorContainer)
                    .clickable { vm.clearNotice() }
                    .padding(10.dp)
            )
        }

        if (permissionDenied) {
            Text(
                "Microphone permission was denied. Calls need the microphone.",
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.bodySmall,
                textAlign = TextAlign.Center
            )
            TextButton(onClick = {
                context.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + context.packageName))
                )
            }) { Text("Open app settings") }
        }

        // Subtitles
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            state = listState,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            items(items = vm.lines, key = { it.id }) { line ->
                when (line.who) {
                    "you" -> Text("You: " + line.text, color = MaterialTheme.colorScheme.onBackground)
                    "zoya" -> Text(
                        "Zoya: " + line.text,
                        color = MaterialTheme.colorScheme.primary
                    )
                    else -> Text(
                        line.text,
                        style = MaterialTheme.typography.bodySmall,
                        fontStyle = FontStyle.Italic,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            if (vm.partial.isNotBlank()) {
                item {
                    Text(
                        "You: " + vm.partial + " …",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Options (language is locked during a call)
        Column(modifier = Modifier.fillMaxWidth()) {
            Text("Speech language", style = MaterialTheme.typography.labelMedium)
            Row(verticalAlignment = Alignment.CenterVertically) {
                LangOption("English (US)", "en-US", vm)
                LangOption("English (IN)", "en-IN", vm)
                LangOption("اردو", "ur-PK", vm)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = vm.bargeIn, onCheckedChange = { vm.setBargeIn(it) })
                Text(
                    "  Headphones mode: interrupt Zoya by talking",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }

        Spacer(Modifier.height(8.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedButton(onClick = { vm.toggleMute() }, enabled = vm.active) {
                Text(if (vm.muted) "Unmute" else "Mute")
            }
            if (vm.active && (vm.state == CallState.SPEAKING || vm.state == CallState.THINKING)) {
                OutlinedButton(onClick = { vm.interrupt() }) { Text("Interrupt") }
            }
            if (vm.active) {
                Button(
                    onClick = { vm.endCall("Call ended.") },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("End call") }
            } else {
                Button(onClick = { begin() }) { Text("📞 Start call") }
            }
        }
    }
}

@Composable
private fun LangOption(label: String, tag: String, vm: CallViewModel) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        RadioButton(
            selected = vm.langTag == tag,
            onClick = { vm.setLanguage(tag) },
            enabled = !vm.active
        )
        Text(label, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(end = 6.dp))
    }
}
